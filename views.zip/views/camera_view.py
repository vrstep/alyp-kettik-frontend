import flet as ft
import flet_camera as fc
from services.api_client import recognize_products


def camera_view(page: ft.Page, on_recognized) -> ft.View:
    """Экран 1: Камера — фото товаров на столе."""

    status_text  = ft.Text("Загрузка камеры...", size=16, text_align=ft.TextAlign.CENTER)
    loading_ring = ft.ProgressRing(visible=True, width=48, height=48)
    scan_btn     = ft.Button(
        "📷  Сфотографировать",
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
        height=52,
        disabled=True,
    )

    # ── Камера ─────────────────────────────────────────────────────────────────
    camera = fc.Camera(
        expand=True,
        preview_enabled=True,
    )

    captured_image: list[bytes] = []  # mutable ref

    # ── Обработка кнопки ───────────────────────────────────────────────────────
    async def on_btn_click(e):
        # Первое нажатие — сделать фото
        if not captured_image:
            status_text.value = "Делаем фото..."
            scan_btn.disabled = True
            page.update()

            try:
                # Захватываем фото
                image_bytes = await camera.take_picture()
                captured_image.append(image_bytes)

                # Показываем превью
                preview_img.src_base64 = image_bytes
                preview_img.visible = True
                camera.visible = False

                scan_btn.text = "🔍  Распознать товары"
                scan_btn.disabled = False
                status_text.value = "Фото готово — нажмите Распознать"
                page.update()
            except Exception as ex:
                status_text.value = f"❌ Ошибка: {ex}"
                scan_btn.disabled = False
                page.update()
            return

        # Второе нажатие — распознать
        scan_btn.disabled = True
        loading_ring.visible = True
        status_text.value = "⏳ Распознаём товары с помощью ИИ..."
        page.update()

        try:
            result = await recognize_products(captured_image[0])
            on_recognized(result)  # переход на экран корзины
        except Exception as ex:
            status_text.value = f"❌ Ошибка: {ex}"
        finally:
            scan_btn.disabled = False
            loading_ring.visible = False
            page.update()

    scan_btn.on_click = on_btn_click

    # ── Переснять ─────────────────────────────────────────────────────────────
    def on_retake(e):
        captured_image.clear()
        preview_img.visible = False
        camera.visible = True
        scan_btn.text = "📷  Сфотографировать"
        scan_btn.disabled = False
        status_text.value = "Сфотографируйте товары на столе"
        page.update()

    retake_btn = ft.Button(
        "Переснять",
        visible=False,
        style=ft.ButtonStyle(
            bgcolor=ft.Colors.TRANSPARENT,
            padding=ft.Padding.symmetric(horizontal=16, vertical=8),
        ),
        on_click=on_retake,
    )

    # ── Превью изображения ────────────────────────────────────────────────────
    preview_img = ft.Image(
        src_base64="",
        visible=False,
        border_radius=12,
        height=300,
        fit=ft.ImageFit.CONTAIN,
    )

    # ── Инициализация камеры ───────────────────────────────────────────────────
    async def init_camera():
        try:
            cameras = await camera.get_available_cameras()
            if cameras:
                await camera.initialize(
                    description=cameras[0],
                    resolution_preset=fc.ResolutionPreset.HIGH,
                    image_format_group=fc.ImageFormatGroup.JPEG,
                )
                scan_btn.disabled = False
                status_text.value = "Сфотографируйте товары на столе"
                loading_ring.visible = False
                page.update()
            else:
                status_text.value = "Камера не найдена"
                loading_ring.visible = False
                page.update()
        except Exception as ex:
            status_text.value = f"Ошибка камеры: {ex}"
            loading_ring.visible = False
            page.update()

    # Запускаем инициализацию камеры асинхронно
    page.run_task(init_camera)

    return ft.View(
        "/camera",
        [
            ft.AppBar(title=ft.Text("Cashierless Store"), center_title=True, bgcolor=ft.Colors.BLUE_700),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Icon(ft.Icons.CAMERA_ALT, size=64, color=ft.Colors.BLUE_700),
                        status_text,
                        ft.Container(
                            content=camera,
                            width=float("inf"),
                            height=300,
                            bgcolor=ft.Colors.BLACK,
                            border_radius=12,
                        ),
                        preview_img,
                        loading_ring,
                        scan_btn,
                        retake_btn,
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=16,
                ),
                padding=24,
                expand=True,
            ),
        ],
    )